package service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.EmployeeEntity;

@Stateless
@LocalBean
public class EmployeeEJB {
	
	@PersistenceContext
	private EntityManager em;
	

	public EmployeeEJB() {
		// TODO Auto-generated constructor stub
	}
	public void AddNew(EmployeeEntity employeeEntity) {
		System.out.println("====================adding employee to the DB");
		em.persist(employeeEntity);
	}

}
